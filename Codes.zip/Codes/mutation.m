function [NewWeights1,NewWeights2] = mutation(Weights1,Weights2)


	NewWeights1 = Weights1;
	NewWeights2 = Weights2;
	
	NewWeights1(randi([1,4]),randi([1,3])) = rand() - rand();
	NewWeights2(randi([1,3]),randi([1,4])) = rand() - rand();
	
end
