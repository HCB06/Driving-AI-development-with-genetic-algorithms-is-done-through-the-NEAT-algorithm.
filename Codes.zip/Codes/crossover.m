function [NewWeights1,NewWeights2] = crossover(BestWeights1,BestWeights2,OldWeights1,OldWeights2)

	
	CutStart1 = randi([1,4]);
	
	do
	
		CutEnd1 = randi([1,4]);
	
	until(CutEnd1 >= CutStart1)
	
	CutStart2 = randi([1,3]);
	
	do
		CutEnd2 = randi([1,3]);
	
	until(CutEnd2 >= CutStart2)
	
	NewWeights1 = BestWeights1;
	NewWeights2 = BestWeights2;

NewWeights1(CutStart1:CutEnd1,CutStart2:CutEnd2) = OldWeights1(CutStart1:CutEnd1,CutStart2:CutEnd2);
	
	
	CutStart1 = randi([1,3]);
	
	do
	
		CutEnd1 = randi([1,3]);
	
	until(CutEnd1 >= CutStart1)
	
	CutStart2 = randi([1,4]);
	
	do
		CutEnd2 = randi([1,4]);
	
	until(CutEnd2 >= CutStart2)

NewWeights2(CutStart1:CutEnd1,CutStart2:CutEnd2) = OldWeights2(CutStart1:CutEnd1,CutStart2:CutEnd2);

end



