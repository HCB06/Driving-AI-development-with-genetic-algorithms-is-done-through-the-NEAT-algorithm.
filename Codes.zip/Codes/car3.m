function car3(Car3W1,Car3W2)

	try

		for i = 1:3

			input_layer(i) = load(sprintf('input3%d.txt',i));

		end



[output_layer] = ysa(input_layer,Car3W1,Car3W2);

output_layer = exp(output_layer);
output_layer = output_layer / sum(output_layer);

kaydet(3,output_layer);

	catch

		pause(0.1)
		car3(Car3W1,Car3W2);

	end