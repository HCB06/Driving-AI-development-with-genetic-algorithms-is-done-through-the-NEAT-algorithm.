function kaydet(car,output_layer)


dosya_adi = sprintf('time%d.txt', car);
Scores = load(dosya_adi);
CarsScores(car) = Scores;

if CarsScores(car) ~= 0

	output_layer = zeros(3);

end


	for i = 1:3

			dosya_adi = sprintf('output%d%d.txt',car, i); % Dosya adını oluştur
			fid = fopen(fullfile(pwd, dosya_adi), 'w'); % 'w' modu, dosyayı yazma modunda açar

			if fid == -1
				pause(0.1)
				kaydet(car,output_layer)
				disp('Dosya açma hatası veya izin hatası!');
			
			else

			fprintf(fid, '%f', output_layer(i)); % Elemanı dosyaya yaz

			if fclose(fid) == -1
				disp('Dosyayı kapatma hatası!');
			end
		end

	end