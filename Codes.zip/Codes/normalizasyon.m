function [scaled_vector] = normalizasyon(vector)

		
	abs_vector = abs(vector);
    max_abs = max(abs_vector(:));
    scaled_vector = vector / max_abs;