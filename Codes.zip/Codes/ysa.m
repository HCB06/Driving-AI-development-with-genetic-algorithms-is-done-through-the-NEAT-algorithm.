function [output_layer] = ysa(input_layer,weights1,weights2)
																							
			[input_layer] = input_normalizasyon(input_layer);		
	
			hidden_layer1 = (weights1 * input_layer');					%% GİZLİ KATMAN 1 %%
																							
			output_layer = (weights2 * hidden_layer1);					%% ÇIKTI KATMANI %%