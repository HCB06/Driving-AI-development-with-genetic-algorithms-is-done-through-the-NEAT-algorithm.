function car2(Car2W1,Car2W2)

	try

		for i = 1:3

			input_layer(i) = load(sprintf('input2%d.txt',i));

		end



[output_layer] = ysa(input_layer,Car2W1,Car2W2);

output_layer = exp(output_layer);
output_layer = output_layer / sum(output_layer);

kaydet(2,output_layer);

	catch
	
		pause(0.1)
		car2(Car2W1,Car2W2);

	end