function start()

TimerRefresher = 0;

for i = 1:3
    dosya_adi = sprintf('time%d.txt', i);
    fid = fopen(dosya_adi, 'w');

    if fid == -1
        disp('Dosya açma hatası veya izin hatası!');
    else
        fprintf(fid, '%d\n', round(TimerRefresher));
        if fclose(fid) == -1
            disp('Dosyayı kapatma hatası!');
        end
    end
end

for i = 1:3
    dosya_adi = sprintf('output%d1.txt', i);
    fid = fopen(dosya_adi, 'w');

    if fid == -1
        disp('Dosya açma hatası veya izin hatası!');
    else
        fprintf(fid, '%d\n', 0);
        if fclose(fid) == -1
            disp('Dosyayı kapatma hatası!');
        end
    end
end



AllStatus = 0;

dosya_adi = 'timer_controller.txt';
fid = fopen(dosya_adi, 'w');

if fid == -1
    disp('Dosya açma hatası veya izin hatası!');
else
    fprintf(fid, '%d\n', round(AllStatus));
    fclose(fid);
end

Car1W1 = rand(4, 3) - rand(4, 3);
Car1W2 = rand(3, 4) - rand(3, 4);

Car2W1 = rand(4, 3) - rand(4, 3);
Car2W2 = rand(3, 4) - rand(3, 4);

Car3W1 = rand(4, 3) - rand(4, 3);
Car3W2 = rand(3, 4) - rand(3, 4);

Gen = 1;

while 1

	car1(Car1W1,Car1W2);
	car2(Car2W1,Car2W2);
	car3(Car3W1,Car3W2);
	

try
	
	
	for i = 1:3

		dosya_adi = sprintf('time%d.txt', i);
		Scores = load(dosya_adi);
		CarsScores(i) = Scores;


		
		if max(CarsScores) > 0 && min(CarsScores) ~= 0
			
			AllStatus = 1;
			
		
	
		
			
			for j = 1:3
			
				if CarsScores(j) ~= max(CarsScores) && CarsScores(j) ~= min(CarsScores)
			
					AvarageFenotypeIndex = j;
			
				end
				
				if CarsScores(j) == max(CarsScores)
				
					BestFenotypeIndex = j;
				
				end
				
				if CarsScores(j) == min(CarsScores)
				
					WorstFenotypeIndex = j;
				
				end
				
			end
			
		end
		
		end


catch


end
	if AllStatus == 1
			
			
			dosya_adi = 'timer_controller.txt';
			fid = fopen(dosya_adi, 'w');

		if fid == -1
			disp('Dosya açma hatası veya izin hatası!');
			else
				fprintf(fid, '%d\n', AllStatus);
			if fclose(fid) == -1
				disp('Dosyayı kapatma hatası!');
			end
		end

				
				
				if BestFenotypeIndex == 1
				
					BestWeights1 = Car1W1;
					BestWeights2 = Car1W2;
					
					elseif BestFenotypeIndex == 2
						
						BestWeights1 = Car2W1;
						BestWeights2 = Car2W2;
						
						elseif BestFenotypeIndex == 3
						
							BestWeights1 = Car3W1;
							BestWeights2 = Car3W2;
							
				end
				
				
				if AvarageFenotypeIndex == 1
				
					AvarageWeights1 = Car1W1;
					AvarageWeights2 = Car1W2;
				
					elseif AvarageFenotypeIndex == 2
						
						AvarageWeights1 = Car2W1;
						AvarageWeights2 = Car2W2;
						
						elseif AvarageFenotypeIndex == 3
						
							AvarageWeights1 = Car3W1;
							AvarageWeights2 = Car3W2;
							
				end
				
				
				if WorstFenotypeIndex == 1
				
					WorstWeights1 = Car1W1;
					WorstWeights2 = Car1W2;
					
					elseif WorstFenotypeIndex == 2
						
						WorstWeights1 = Car2W1;
						WorstWeights2 = Car2W2;
						
						elseif WorstFenotypeIndex == 3
						
							WorstWeights1 = Car3W1;
							WorstWeights2 = Car3W2;
				end
				
				
				
				[NewWeights1,NewWeights2] = crossover(BestWeights1,BestWeights2,AvarageWeights1,AvarageWeights2);
				[NewWeights1,NewWeights2] = mutation(NewWeights1,NewWeights2);
				
				AvarageWeights1 = NewWeights1;
				AvarageWeights2 = NewWeights2;
				
				[NewWeights1,NewWeights2] = crossover(BestWeights1,BestWeights2,AvarageWeights1,AvarageWeights2);
				[NewWeights1,NewWeights2] = mutation(NewWeights1,NewWeights2);
				

				WorstWeights1 = NewWeights1;
				WorstWeights2 = NewWeights2;
				
				
				
				if AvarageFenotypeIndex == 1
				
					Car1W1 = AvarageWeights1;
					Car1W2 = AvarageWeights2;
				
					elseif AvarageFenotypeIndex == 2
						
						Car2W1 = AvarageWeights1;
						Car2W2 = AvarageWeights2;
						
						elseif AvarageFenotypeIndex == 3
						
							Car3W1 = AvarageWeights1;
							Car3W2 = AvarageWeights2;
							
				end
				
							
				if WorstFenotypeIndex == 1
				
					Car1W1 = WorstWeights1;
					Car1W2 = WorstWeights2;
				
					elseif AvarageFenotypeIndex == 2
						
						Car2W1 = WorstWeights1;
						Car2W2 = WorstWeights2;
						
						elseif AvarageFenotypeIndex == 3
						
							Car3W1 = WorstWeights1;
							Car3W2 = WorstWeights2;
							
				end
				
				pause(3)
				
				AllStatus = 0;
				
				dosya_adi = 'timer_controller.txt';
				fid = fopen(dosya_adi, 'w');

				if fid == -1
					disp('Dosya açma hatası veya izin hatası!');
				else
					fprintf(fid, '%d\n', round(AllStatus));
					fclose(fid);
				end

				
				for i = 1:3
					dosya_adi = sprintf('time%d.txt', i);
					fid = fopen(dosya_adi, 'w');

					if fid == -1
						disp('Dosya açma hatası veya izin hatası!');
					else
						fprintf(fid, '%d\n', round(TimerRefresher));
						if fclose(fid) == -1
							disp('Dosyayı kapatma hatası!');
						end
					end
				end
				
				%{
				save('weights/weight1.mat','BestWeights1');
				save('weights/weight2.mat','BestWeights2');
				
				%}
				disp('Gen:');
				Gen++

	end

end


