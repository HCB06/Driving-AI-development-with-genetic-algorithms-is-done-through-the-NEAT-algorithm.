function [scaled_vector] = input_normalizasyon(vector)


		min_value = min(vector(:));
		max_value = max(vector(:));
		
		scaled_vector = 0 + (vector - min_value) * (1 - 0) / (max_value - min_value); % Ölçeklendirme