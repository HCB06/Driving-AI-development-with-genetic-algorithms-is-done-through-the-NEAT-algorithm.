function car1(Car1W1,Car1W2)

	try	
	
		for i = 1:3

			input_layer(i) = load(sprintf('input1%d.txt',i));

		end
	


[output_layer] = ysa(input_layer,Car1W1,Car1W2);

output_layer = exp(output_layer);
output_layer = output_layer / sum(output_layer);

kaydet(1,output_layer);

	catch
	
		pause(0.1)
		car1(Car1W1,Car1W2);
	
	end

